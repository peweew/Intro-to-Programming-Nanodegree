$(document).ready(function(){         /*input form effect*/
    $("input").focus(function(){
        $(this).css("background-color", "#F1F1F1");
    });
    $("input").blur(function(){
        $(this).css("background-color", "#ffffff");
    });
    $("textarea").focus(function(){
        $(this).css("background-color", "#F1F1F1");
    });
    $("textarea").blur(function(){
        $(this).css("background-color", "#ffffff");
    });
	

});

 